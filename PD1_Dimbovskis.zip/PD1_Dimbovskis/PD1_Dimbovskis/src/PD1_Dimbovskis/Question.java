package PD1_Dimbovskis;

/**
 *
 * @author Vadims Dimbovskis PR-21
 */
public class Question {
    public void Question(String text, String answer){
    }
    public void getText(){
    }
    public boolean isCorrect(String answer){
        return true;
    }
}
