package PD1_Dimbovskis;

/**
 *
 * @author Vadims Dimbovskis PR-21
 */
public class Admin {
    private void addQuestion(String text, String answer, int rightAnswer){
    }
    private void deleteUser(String login){
    }
    public void addText(){
    }
    public void startText(){
    }
    private void addUser(String name, String login, String password, String repeation){
    }
}
