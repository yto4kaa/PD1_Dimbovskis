package PD1_Dimbovskis;

/**
 *
 * @author Vadims Dimbovskis PR-21
 */
public class User {
    public void User(String name, String login, String password){
    }
    private boolean enter(String login, String password){
        return true;
    }
}
