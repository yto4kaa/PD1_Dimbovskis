package PD1_Dimbovskis;

import java.util.List;

/**
 *
 * @author Vadims Dimbovskis PR-21
 */
public class Test {
    private void saveResult(){
    }
    private void getResult(){
    }
    public void Test(String name,List question){
    }
    public boolean isOpen(){
        return true;
    }
    public void getQuestion(int question){
    }
    
}
