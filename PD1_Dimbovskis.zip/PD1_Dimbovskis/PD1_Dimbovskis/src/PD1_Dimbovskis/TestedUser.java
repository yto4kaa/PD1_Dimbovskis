package PD1_Dimbovskis;

/**
 *
 * @author Vadims Dimbovskis PR-21
 */
public class TestedUser {
    public void getAnswer(Question question, String answer){
    }
    public void clear(){
    }
}
